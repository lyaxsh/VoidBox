# macOS-cursor
this is the collection of original macOS cursors for using on Windows!
